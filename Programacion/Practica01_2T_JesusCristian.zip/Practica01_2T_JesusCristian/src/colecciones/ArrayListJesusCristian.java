package colecciones;

import java.util.*;

public class ArrayListJesusCristian extends Arboles
{

	
	
	public ArrayListJesusCristian(String nombre, double altura, int a�osEdad, String lugarOrigen, boolean hojaCaduca) 
	{
		super(nombre, altura, a�osEdad, lugarOrigen, hojaCaduca);
	}

	public static void main(String[] args) 
	{
			
		boolean existe= false;
			
			
			ArrayList<Arboles> misArbolesAL = new ArrayList<Arboles>();
			
			misArbolesAL.add(new ArrayListJesusCristian("Roble",12.5, 80, "Canada", true));
			misArbolesAL.add(new ArrayListJesusCristian("Encina", 5.25, 90, "Espa�a", false));
			misArbolesAL.add(new ArrayListJesusCristian("Pino Laricio", 22.5, 80, "Italia", false));
			misArbolesAL.add(new ArrayListJesusCristian("Roble",  5.5, 15, "Canada", true));
			misArbolesAL.add(new ArrayListJesusCristian("Manzano", 3.5, 60, "India", false));
			
			Arboles listaArray[] = new  Arboles[misArbolesAL.size()];
			
			
			if(misArbolesAL.isEmpty()==true) 
			{
				System.out.println("El array list est� vacio");
			}
			else 
			{
				
				listaArray = misArbolesAL.toArray(listaArray);
			}
			
			
			
			
			
			for (int i=0; i<misArbolesAL.size(); i++)
			{  
				 if(misArbolesAL.get(i).getNombre() == "Peral" && misArbolesAL.get(i).getLugarOrigen() == "Canad�")
					 existe = true;
			}
			
			 if (existe == true)
					System.out.println("* El �rbol Peral de lugar de origen Canad�, existe");
				else
					System.out.println("* El �rbol Peral de lugar de origen Canad�, no existe");
			 
			
			
			
			for (int i=0; i<misArbolesAL.size(); i++) 
			{  
				
				boolean encontrado=false;
				
				if(misArbolesAL.get(i).getAltura() == 3.5 ) 
				{
					
					
					encontrado=true; 
					System.out.println("* La posici�n del �rbol de 3.5 de alto est� en la posici�n "+i);
					
				}
				else if(misArbolesAL.get(i).getAltura() != 3.5)
				{  
					
				}
				else if(encontrado==false) 
				{ 
				
					System.out.println("* La posici�n del �rbol de 3.5 de alto no se encuentra");
				}
			}
			
			
			
			
			for (int i=0; i<misArbolesAL.size(); i++) { 
				
				if(misArbolesAL.get(i).getNombre() == "Encina" ) {
					
					misArbolesAL.get(i).setA�osEdad(95);
					
					System.out.println("* Edad de Encina de 90 a�os se ha cambiado a 95");
			}
			}
			
			
			//7
			for (int i=0; i<misArbolesAL.size(); i++) {
				
				if(misArbolesAL.get(i).getNombre() == "Roble" && misArbolesAL.get(i).isHojaCaduca()==true ) {
					
					misArbolesAL.remove(i);
				
				}
			}
			System.out.println("* Se ha borrado el Roble de hoja caduca");
			
			
			System.out.println();
			misArbolesAL.trimToSize();
			
			
			
			
			
			Comparator<Arboles> comparator= new Comparator<Arboles>() 
			{
				@Override
				public int compare(Arboles o1, Arboles o2) {
				
					return new Integer(o2.getA�osEdad()).compareTo(new Integer(o1.getA�osEdad()));
				}
			};
			Collections.sort(misArbolesAL,comparator);
			
		
			
			
			System.out.println("");
			System.out.println("Listo ArrayList");
			System.out.println("===============");
			
			for (Arboles a: misArbolesAL) 
			{
					System.out.println(a);
			}
			
			System.out.println("");
			System.out.println("Listo Array");
			System.out.println("===========");
			
			for (Arboles b: listaArray) 
			{
					System.out.println(b);
			}
			
		
			

	}


}

	
