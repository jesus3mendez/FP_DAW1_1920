package colecciones;
import java.util.HashMap;

public class HashMapJesusCristian {
	
		public static void main(String[] args) {
			
			
			HashMap<Integer, String> miHS = new HashMap<Integer, String>();
			
			miHS.put(1, "Maria Salomea Sklodowsk");
			miHS.put(2, "Santiago Ram�n y Cajal");
			miHS.put(3, "T�ano de Crotona");
			miHS.put(4, "Mariano Barbacid");
			miHS.put(5, "Augusta Ada Byron");
			
			HashMap<Integer, String> miHSNacionalidad = new HashMap<Integer, String>();
			
			miHSNacionalidad.put(1, "Polaca");
			miHSNacionalidad.put(2, "Espa�ola");
			miHSNacionalidad.put(3, "Griega");
			miHSNacionalidad.put(4, "Espa�ola");
			miHSNacionalidad.put(5, "Inglesa");
		
			System.out.println("El HashMap tiene una longitud de "+miHS.size()+" elementos. ");
			
			
			System.out.println("");
			System.out.println("Posici�n: "+1+". Nombre: "+miHS.get(1)+". Nacionaidad: "+miHSNacionalidad.get(1));
			System.out.println("Posici�n: "+2+". Nombre: "+miHS.get(2)+". Nacionaidad: "+miHSNacionalidad.get(2));
			System.out.println("Posici�n: "+3+". Nombre: "+miHS.get(3)+". Nacionaidad: "+miHSNacionalidad.get(3));
		
		
			
			miHS.replace(4, "Mariano Barbacid ", "Margarita Salas Falgueras");
		
		
			System.out.println("");
			System.out.println("Impresi�n del HashMap completo");
			System.out.println("==============================");
			System.out.println("Posici�n: "+1+" *** Nombre: "+miHS.get(1));
			System.out.println("Posici�n: "+2+" *** Nombre: "+miHS.get(2));
			System.out.println("Posici�n: "+3+" *** Nombre: "+miHS.get(3));
			System.out.println("Posici�n: "+4+" *** Nombre: "+miHS.get(4));
			System.out.println("Posici�n: "+5+" *** Nombre: "+miHS.get(5));
		}

	}


