package colecciones;

public class Arboles 
{

	private double altura;
	private int a�osEdad;
	private String lugarOrigen;
	private boolean hojaCaduca;
	private String nombre;
	
	
	public Arboles(String nombre, double altura, int a�osEdad, String lugarOrigen, boolean hojaCaduca) {
		super();
		this.altura = altura;
		this.a�osEdad = a�osEdad;
		this.lugarOrigen = lugarOrigen;
		this.hojaCaduca = hojaCaduca;
		this.nombre = nombre;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getAltura() {
		return altura;
	}
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public int getA�osEdad() {
		return a�osEdad;
	}
	public void setA�osEdad(int a�osEdad) {
		this.a�osEdad = a�osEdad;
	}
	
	public String getLugarOrigen() {
		return lugarOrigen;
	}
	public void setLugarOrigen(String lugarOrigen) {
		this.lugarOrigen = lugarOrigen;
	}
	public boolean isHojaCaduca() {
		return hojaCaduca;
	}
	public void setHojaCaduca(boolean hojaCaduca) {
		this.hojaCaduca = hojaCaduca;
	}
	
	public String toString() 
	{
		String sino;
	
		if(hojaCaduca==true)
		{
			sino="Si";
		}else {
			sino="No";
		}
		
		String msj = "\nNombre del �rbol: "+nombre+"\nAltura: "+altura+"\nEdad en a�os: "+a�osEdad+
					"\nLugar de origen: "+lugarOrigen+"\nHoja caduca: "+sino+"\n***********************";
		return msj;
	}
	
	
	
}
