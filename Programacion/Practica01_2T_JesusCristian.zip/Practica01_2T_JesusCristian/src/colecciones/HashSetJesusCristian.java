package colecciones;
import java.util.*;

public class HashSetJesusCristian extends Arboles
{
	public HashSetJesusCristian(String nombre, double altura, int a�osEdad, String lugarOrigen, boolean hojaCaduca) 
	{
		super(nombre, altura, a�osEdad, lugarOrigen, hojaCaduca);
	}

	public static void main(String[] args)
	{
		
		
		HashSet<Arboles> misArbolesHS = new HashSet<Arboles>();
		
		misArbolesHS.add(new HashSetJesusCristian("Roble", 12.5, 80, "Canada", true));
		misArbolesHS.add(new HashSetJesusCristian("Encina", 5.25, 90, "Espa�a", false));
		misArbolesHS.add(new HashSetJesusCristian("Pino Laricio", 22.5, 80, "Italia", false));
		misArbolesHS.add(new HashSetJesusCristian("Roble",  5.5, 15, "Canada", true));
		misArbolesHS.add(new HashSetJesusCristian("Manzano", 3.5, 60, "India", false));
		
		Arboles ArbolesHS[] = new Arboles[misArbolesHS.size()];
		
		if(misArbolesHS.size() != 0)
		{
			ArbolesHS = misArbolesHS.toArray(ArbolesHS);
		}
		
		
		System.out.println();
		System.out.println("El tama�o del HashSet es de "+misArbolesHS.size()+" elementos");
		
		
		System.out.println();
		misArbolesHS.toArray();
		
	
		System.out.println();
		System.out.println("Listo el array");
		System.out.println("==============");
		for (Arboles c: misArbolesHS) 
		{
				System.out.println(c);
		}
		
		System.out.println("");
		System.out.println("Listo HashSet");
		System.out.println("=============");
		for(Arboles o: ArbolesHS){
			System.out.println(o);
		}
	}
}
